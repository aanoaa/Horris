package Horris::Connection::Plugin;
BEGIN {
  $Horris::Connection::Plugin::VERSION = '0.0.1';
}
use Moose;
use namespace::clean -except => qw/meta/;

has connection => (
	is => 'ro', 
	isa => 'Horris::Connection', 
	writer => '_connection'
);

has is_enable => (
	traits => ['Bool'], 
	is => 'rw', 
	isa => 'Bool', 
	default => 1, 
	handles => {
		enable => 'set', 
		disable => 'unset', 
		_switch => 'toggle', 
		is_disable => 'not'
	}
);

sub init {
	my ($self, $conn) = @_;
	my $pname = ref $self;
	print ref $self, " on - ", $self->is_enable ? 'enable' : 'disable', "\n" if $Horris::DEBUG;
	$self->_connection($conn);
}

around BUILDARGS => sub {
	my ($orig, $class, @args) = @_;
	my $self = $class->$orig(@args);
	my @reserve_keys = qw/parent name/;
	while (my ($key, $value) = each %{ $self->{parent}{plugin}{$self->{name}} }) {
		confess 'keys [' . join(', ', @reserve_keys) . "] are reserved\n" if grep { $key eq $_ } @reserve_keys;
		$self->{$key} = $value;
	}

	return $self;
};

__PACKAGE__->meta->make_immutable;

1;

__END__

=head1 NAME

Horris::Connection::Plugin - base class of plugins

=head1 VERSION

version 0.0.1

=head1 SYNOPSIS

    package Horris::Connection::Plugin::Foo;
    use Moose;
    with qw/Horris::Connection::Plugin MooseX::Role::Pluggable::Plugin/;

	# override member variables if you want.
	has '+is_enable' => (
		default => 0	# $self->is_enable is false
	);

	sub init {
		# initialize plugin stuff here
	}

	sub on_connect {
		# implement on_connect stuff here
	}

	sub on_disconnect {
		# implement on_disconnect stuff here
	}

	sub irc_privmsg {
		my ($self, $message) = @_;
		#	this hook method will called by Horris::Connection
		#	when 'irc_privmsg' event occur in joinning irc channels
		#	see the AnyEvent::IRC::Client for 'irc_privmsg' more detail
		#
		# implement irc_privmsg stuff here
	}

	sub on_privatemsg {
		my ($self, $nick, $message) = @_;
		# this hook method will called when who send a private message to
		# your bot. 
	}

	__PACKAGE__->meta->make_immutable;

    # see the documentation for MooseX::Role::Pluggable,
	# MooseX::Role::Pluggable::Plugin for info on how to get your Moose
	# class to use this plugin...

=head1 SEE ALSO

L<MooseX::Role::Pluggable> L<MooseX::Role::Pluggable::Plugin> L<Horris::Connection>

=cut