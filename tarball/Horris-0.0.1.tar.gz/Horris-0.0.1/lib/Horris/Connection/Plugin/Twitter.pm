package Horris::Connection::Plugin::Twitter;
BEGIN {
  $Horris::Connection::Plugin::Twitter::VERSION = '0.0.1';
}
use Moose;
use HTTP::Request;
use HTTP::Response;
use LWP::UserAgent;
extends 'Horris::Connection::Plugin';
with 'MooseX::Role::Pluggable::Plugin';

sub irc_privmsg {
	my ($self, $message) = @_;
	my $url = $message->message;
	$url =~ s/#!\///;
	if ($url !~ m{^\s*http://twitter.com/(.*)?/status/[0-9]+\s*$}) {
		return;
	}

	print "recv Twitter URI\n" if $Horris::DEBUG;

	my $msg;
	my $request  = HTTP::Request->new( GET => $url );
	my $ua       = LWP::UserAgent->new;
	my $response = $ua->request($request);
	$msg = $response->status_line unless $response->is_success;
	($msg) = $response->content =~ m{<meta content="(.*?)" name="description" />};
	$self->connection->irc_notice({
		channel => $message->channel, 
		message => $msg
	});
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=head1 NAME

Horris::Connection::Plugin::Twitter

=head1 VERSION

version 0.0.1

=head1 SYNOPSIS

when bot got a twitter url, notice the title.

=cut